# ☠️ SITANI THE HACKER DEATH BOT v3.5.5

A modular WhatsApp Web utility and group-moderation bot built with Node.js and Baileys. It includes QR login or phone-number pairing, a menu image, useful API commands, and admin-gated group tools.

> This is an unofficial community project, not affiliated with WhatsApp. Use it only with an account you control, follow WhatsApp's terms, respect group members, and avoid unsolicited/bulk messaging. Unofficial WhatsApp Web libraries can stop working or lead to account restrictions.

## Requirements

- Node.js 20 or newer
- A WhatsApp account you control
- A VPS for always-on hosting (or a computer for local testing)

## Install

```bash
git clone YOUR_REPOSITORY_URL
cd sitin-ban-tools
npm install
cp .env.example .env
```

Edit `.env` on the VPS. Never commit `.env`, `auth_info/`, or API keys to GitHub.

### QR login

Leave `PAIRING_NUMBER` blank in `.env`, then run:

```bash
npm start
```

Scan the terminal QR using WhatsApp → Linked devices → Link a device.

### Pairing-code login

Set `PAIRING_NUMBER` to your own phone number with country code and digits only (for example, Uganda starts with `256`; do not include `+`, spaces, or dashes). Run `npm start` and enter the displayed code in WhatsApp → Linked devices → Link with phone number instead.

Do not share QR codes, pairing codes, or the `auth_info/` folder. They give access to your linked WhatsApp session.

## Commands included in this starter

- General: `.menu`, `.help`, `.ping`, `.alive`, `.info`, `.about`, `.runtime`, `.owner`
- Tools: `.calc`
- APIs: `.weather`, `.define`, `.wiki`, `.currency`, `.joke`, `.ai`, `.github`, `.shorten`
- Group tools: `.tagall`, `.warn`, `.warnings`, `.resetwarn`, `.kick`, `.antilink`, `.delete`

Examples:

```text
.weather Kampala
.define curious
.wiki Uganda
.currency 10 USD UGX
.ai Explain how solar panels work
.calc 12*(4+2)
```

Weather, dictionary, Wikipedia, currency, joke, GitHub lookup, and URL shortening use public web APIs. `.ai` requires an API key and may incur charges. Add `OPENAI_API_KEY` and optionally `OPENAI_MODEL` to the private VPS `.env` file. Never paste secrets into WhatsApp or source code.

## Group moderation

The bot must be an admin for `.kick`, `.delete`, and automatic invite-link deletion. The person invoking admin-only commands must also be a group admin. `.antilink on` stores a per-group setting. Test moderation features in a group you control before using them elsewhere.

## VPS process manager

For a simple test, use `npm start`. For long-running hosting, use a process manager such as systemd or PM2 and configure it to restart on failure. Keep `auth_info/` persistent and private.

## Development status

This repository is a working starter with a small set of implemented commands, not a completed 1,500-command release. New commands should be implemented, tested, documented, and added in batches. Do not pad the command count with fake aliases. Some features may require external API keys or may change when third-party services update.

Run syntax checks with:

```bash
npm run check
```
