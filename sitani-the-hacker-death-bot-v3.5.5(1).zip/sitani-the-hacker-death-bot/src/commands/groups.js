import fs from 'node:fs/promises';
const dataDir = new URL('../../data/', import.meta.url);
const readJson = async (name, fallback) => { try { return JSON.parse(await fs.readFile(new URL(name, dataDir), 'utf8')); } catch { return fallback; } };
const writeJson = async (name, value) => { await fs.mkdir(dataDir, { recursive: true }); await fs.writeFile(new URL(name, dataDir), JSON.stringify(value, null, 2)); };
const mentioned = (m) => m.message?.extendedTextMessage?.contextInfo?.mentionedJid || [];

export default [
  { name: 'tagall', category: 'Group', description: 'Mention group members (admins only)', group: true, admin: true, run: async ({ sock, jid, args, metadata }) => {
      const members = metadata.participants.map(p => p.id); const text = args.join(' ') || 'Attention everyone';
      const chunks = [];
      for (let i = 0; i < members.length; i += 40) chunks.push(members.slice(i, i + 40));
      for (const part of chunks) await sock.sendMessage(jid, { text: `📢 ${text}\n\n${part.map(x => `@${x.split('@')[0]}`).join(' ')}`, mentions: part });
    } },
  { name: 'warn', category: 'Group', description: 'Record a warning for a mentioned member (admins only)', group: true, admin: true, run: async ({ sock, jid, message }) => {
      const targets = mentioned(message); if (!targets.length) return sock.sendMessage(jid, { text: 'Mention a member: .warn @member' });
      const db = await readJson('warnings.json', {}); for (const id of targets) db[`${jid}:${id}`] = (db[`${jid}:${id}`] || 0) + 1;
      await writeJson('warnings.json', db); await sock.sendMessage(jid, { text: targets.map(id => `⚠️ @${id.split('@')[0]} now has ${db[`${jid}:${id}`]} warning(s).`).join('\n'), mentions: targets });
    } },
  { name: 'warnings', category: 'Group', description: 'Check warnings for a mentioned member (admins only)', group: true, admin: true, run: async ({ sock, jid, message }) => {
      const targets = mentioned(message); if (!targets.length) return sock.sendMessage(jid, { text: 'Mention a member: .warnings @member' });
      const db = await readJson('warnings.json', {}); return sock.sendMessage(jid, { text: targets.map(id => `@${id.split('@')[0]}: ${db[`${jid}:${id}`] || 0} warning(s)`).join('\n'), mentions: targets });
    } },
  { name: 'resetwarn', category: 'Group', description: 'Clear warnings for a mentioned member (admins only)', group: true, admin: true, run: async ({ sock, jid, message }) => {
      const targets = mentioned(message); if (!targets.length) return sock.sendMessage(jid, { text: 'Mention a member: .resetwarn @member' });
      const db = await readJson('warnings.json', {}); for (const id of targets) delete db[`${jid}:${id}`]; await writeJson('warnings.json', db);
      return sock.sendMessage(jid, { text: 'Warnings cleared for the selected member(s).', mentions: targets });
    } },
  { name: 'kick', category: 'Group', description: 'Remove a mentioned member (admins only)', group: true, admin: true, botAdmin: true, run: async ({ sock, jid, message }) => {
      const targets = mentioned(message); if (!targets.length) return sock.sendMessage(jid, { text: 'Mention a member: .kick @member' });
      await sock.groupParticipantsUpdate(jid, targets, 'remove');
    } },
  { name: 'antilink', category: 'Group', description: 'Enable or disable invite-link filtering (admins only)', group: true, admin: true, run: async ({ sock, jid, args }) => {
      const setting = (args[0] || '').toLowerCase(); if (!['on', 'off'].includes(setting)) return sock.sendMessage(jid, { text: 'Usage: .antilink on OR .antilink off' });
      const db = await readJson('settings.json', {}); db[jid] ||= {}; db[jid].antilink = setting === 'on'; await writeJson('settings.json', db);
      return sock.sendMessage(jid, { text: `Anti-link is now ${setting.toUpperCase()}. The bot must be a group admin to delete link messages.` });
    } },
  { name: 'delete', category: 'Group', description: 'Delete a replied-to message (bot admin may be required)', group: true, admin: true, botAdmin: true, run: async ({ sock, jid, message }) => {
      const ctx = message.message?.extendedTextMessage?.contextInfo; if (!ctx?.stanzaId || !ctx?.participant) return sock.sendMessage(jid, { text: 'Reply to the message you want the bot to delete, then type .delete' });
      await sock.sendMessage(jid, { delete: { remoteJid: jid, fromMe: false, id: ctx.stanzaId, participant: ctx.participant } });
    } }
];

export { readJson };
