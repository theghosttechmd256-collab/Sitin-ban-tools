const safeText = (s, max = 3500) => String(s ?? '').slice(0, max);

export default [
  { name: 'weather', category: 'API', description: 'Current weather by city (Open-Meteo; no key needed)', run: async ({ sock, jid, args }) => {
      const city = args.join(' '); if (!city) return sock.sendMessage(jid, { text: 'Usage: .weather Kampala' });
      const geo = await fetch(`https://geocoding-api.open-meteo.com/v1/search?name=${encodeURIComponent(city)}&count=1&language=en&format=json`).then(r => r.json());
      const place = geo.results?.[0]; if (!place) return sock.sendMessage(jid, { text: 'City not found.' });
      const data = await fetch(`https://api.open-meteo.com/v1/forecast?latitude=${place.latitude}&longitude=${place.longitude}&current=temperature_2m,relative_humidity_2m,apparent_temperature,wind_speed_10m`).then(r => r.json());
      const c = data.current; if (!c) throw Error('Weather data unavailable');
      return sock.sendMessage(jid, { text: `🌦️ *Weather: ${place.name}, ${place.country}*\nTemperature: ${c.temperature_2m}°C\nFeels like: ${c.apparent_temperature}°C\nHumidity: ${c.relative_humidity_2m}%\nWind: ${c.wind_speed_10m} km/h` });
    } },
  { name: 'define', category: 'API', description: 'Look up an English word', run: async ({ sock, jid, args }) => {
      const word = args[0]; if (!word) return sock.sendMessage(jid, { text: 'Usage: .define word' });
      const data = await fetch(`https://api.dictionaryapi.dev/api/v2/entries/en/${encodeURIComponent(word)}`).then(r => r.json());
      const meaning = data[0]?.meanings?.[0]?.definitions?.[0]?.definition;
      return sock.sendMessage(jid, { text: meaning ? `📖 *${data[0].word}*\n${safeText(meaning)}` : 'No definition found.' });
    } },
  { name: 'wiki', category: 'API', description: 'Search Wikipedia summary', run: async ({ sock, jid, args }) => {
      const topic = args.join(' '); if (!topic) return sock.sendMessage(jid, { text: 'Usage: .wiki topic' });
      const data = await fetch(`https://en.wikipedia.org/api/rest_v1/page/summary/${encodeURIComponent(topic)}`).then(r => r.json());
      return sock.sendMessage(jid, { text: data.extract ? `📚 *${data.title}*\n${safeText(data.extract, 2500)}\n\n${data.content_urls?.desktop?.page || ''}` : 'No Wikipedia summary found.' });
    } },
  { name: 'currency', category: 'API', description: 'Convert currencies using Frankfurter', run: async ({ sock, jid, args }) => {
      const [amountText, from, to] = args; const amount = Number(amountText);
      if (!Number.isFinite(amount) || !from || !to) return sock.sendMessage(jid, { text: 'Usage: .currency 10 USD EUR' });
      const data = await fetch(`https://api.frankfurter.app/latest?amount=${amount}&from=${encodeURIComponent(from.toUpperCase())}&to=${encodeURIComponent(to.toUpperCase())}`).then(r => r.json());
      const value = data.rates?.[to.toUpperCase()]; return sock.sendMessage(jid, { text: value === undefined ? 'Currency code not supported.' : `💱 ${amount} ${from.toUpperCase()} = ${value} ${to.toUpperCase()}\nRate date: ${data.date}` });
    } },
  { name: 'joke', category: 'API', description: 'Get a safe general joke', run: async ({ sock, jid }) => {
      const data = await fetch('https://official-joke-api.appspot.com/jokes/general/random').then(r => r.json()); const j = Array.isArray(data) ? data[0] : data;
      return sock.sendMessage(jid, { text: j?.setup ? `😄 ${j.setup}\n${j.punchline}` : 'Joke service is unavailable right now.' });
    } },
  { name: 'ai', category: 'API', description: 'Ask the optional OpenAI API', run: async ({ sock, jid, args, env }) => {
      if (!env.OPENAI_API_KEY) return sock.sendMessage(jid, { text: 'AI is not configured. Add OPENAI_API_KEY to your server .env file, then restart the bot. Never share your key in chat or commit it to GitHub.' });
      const prompt = args.join(' '); if (!prompt) return sock.sendMessage(jid, { text: 'Usage: .ai explain photosynthesis' });
      const response = await fetch('https://api.openai.com/v1/chat/completions', { method: 'POST', headers: { Authorization: `Bearer ${env.OPENAI_API_KEY}`, 'Content-Type': 'application/json' }, body: JSON.stringify({ model: env.OPENAI_MODEL || 'gpt-4.1-mini', messages: [{ role: 'user', content: prompt }], max_tokens: 500 }) });
      const data = await response.json(); if (!response.ok) throw Error(data.error?.message || 'AI API request failed');
      return sock.sendMessage(jid, { text: safeText(data.choices?.[0]?.message?.content || 'No response.', 3500) });
    } },
  { name: 'github', category: 'API', description: 'View public GitHub user profile', run: async ({ sock, jid, args }) => {
      const username = args[0]; if (!username) return sock.sendMessage(jid, { text: 'Usage: .github username' });
      const r = await fetch(`https://api.github.com/users/${encodeURIComponent(username)}`, { headers: { 'User-Agent': 'SITANI-Bot' } });
      if (!r.ok) return sock.sendMessage(jid, { text: 'GitHub user not found or API unavailable.' });
      const u = await r.json(); return sock.sendMessage(jid, { text: `🐙 *${u.login}*\nName: ${u.name || '—'}\nPublic repos: ${u.public_repos}\nFollowers: ${u.followers}\nProfile: ${u.html_url}` });
    } },
  { name: 'shorten', category: 'API', description: 'Shorten a URL using is.gd', run: async ({ sock, jid, args }) => {
      let url; try { url = new URL(args[0]); } catch { return sock.sendMessage(jid, { text: 'Usage: .shorten https://example.com' }); }
      if (!['http:', 'https:'].includes(url.protocol)) return sock.sendMessage(jid, { text: 'Only http/https links are accepted.' });
      const result = await fetch(`https://is.gd/create.php?format=simple&url=${encodeURIComponent(url.href)}`).then(r => r.text());
      return sock.sendMessage(jid, { text: result.startsWith('https://') ? `Short link: ${result}` : 'Could not shorten this URL.' });
    } }
];
