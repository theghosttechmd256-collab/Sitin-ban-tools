import os from 'node:os';

const startedAt = Date.now();
const fmtDuration = (ms) => {
  const s = Math.floor(ms / 1000);
  const d = Math.floor(s / 86400), h = Math.floor((s % 86400) / 3600), m = Math.floor((s % 3600) / 60), sec = s % 60;
  return `${d}d ${h}h ${m}m ${sec}s`;
};

export default [
  { name: 'menu', aliases: ['help', 'commands'], category: 'General', description: 'Show the command menu', run: async ({ sock, jid, prefix, botName, menuImage }) => {
      const body = `☠️ *${botName} v3.5.5*\n\n` +
        `╭─〔 GENERAL 〕\n│ ${prefix}ping\n│ ${prefix}alive\n│ ${prefix}info\n│ ${prefix}runtime\n│ ${prefix}owner\n│ ${prefix}about\n╰────────────\n` +
        `╭─〔 LOOKUP & API 〕\n│ ${prefix}weather city\n│ ${prefix}define word\n│ ${prefix}wiki topic\n│ ${prefix}currency 10 USD EUR\n│ ${prefix}joke\n│ ${prefix}ai question\n╰────────────\n` +
        `╭─〔 GROUP TOOLS 〕\n│ ${prefix}tagall\n│ ${prefix}warn @user\n│ ${prefix}warnings @user\n│ ${prefix}resetwarn @user\n│ ${prefix}kick @user\n│ ${prefix}antilink on/off\n│ ${prefix}delete (reply)\n╰────────────\n` +
        `╭─〔 TOOLS 〕\n│ ${prefix}calc 12*(4+2)\n│ ${prefix}shorten URL\n│ ${prefix}github username\n╰────────────\n\n` +
        `Commands are added in tested batches. Use ${prefix}help <command> for details.`;
      if (menuImage) await sock.sendMessage(jid, { image: menuImage, caption: body });
      else await sock.sendMessage(jid, { text: body });
    } },
  { name: 'ping', category: 'General', description: 'Check bot response', run: async ({ sock, jid }) => sock.sendMessage(jid, { text: '🏓 Pong! SITANI is online.' }) },
  { name: 'alive', category: 'General', description: 'Check bot status', run: async ({ sock, jid, botName }) => sock.sendMessage(jid, { text: `✅ ${botName} is alive.` }) },
  { name: 'info', category: 'General', description: 'Show bot information', run: async ({ sock, jid, botName }) => sock.sendMessage(jid, { text: `☠️ ${botName}\nVersion: 3.5.5\nRuntime: Node.js ${process.version}\nPlatform: ${process.platform}\nCommands: modular registry` }) },
  { name: 'about', category: 'General', description: 'About this project', run: async ({ sock, jid }) => sock.sendMessage(jid, { text: 'SITANI is a configurable WhatsApp utility and group-moderation bot. Use responsibly and respect WhatsApp rules and group members.' }) },
  { name: 'runtime', category: 'General', description: 'Show uptime', run: async ({ sock, jid }) => sock.sendMessage(jid, { text: `⏱️ Bot uptime: ${fmtDuration(Date.now() - startedAt)}\n🖥️ System uptime: ${fmtDuration(os.uptime() * 1000)}` }) },
  { name: 'owner', category: 'General', description: 'Show owner contact if configured', run: async ({ sock, jid, ownerNumber }) => sock.sendMessage(jid, { text: ownerNumber ? `Owner: ${ownerNumber}` : 'Owner contact has not been configured.' }) },
  { name: 'calc', category: 'Tools', description: 'Evaluate basic arithmetic', run: async ({ sock, jid, args }) => {
      const expr = args.join('').replace(/\s/g, '');
      if (!expr || expr.length > 80 || !/^[0-9+*/().%\-]+$/.test(expr)) return sock.sendMessage(jid, { text: 'Usage: .calc 12*(4+2)\nOnly basic arithmetic is supported.' });
      try {
        // Small recursive-descent parser; deliberately does not use eval().
        let i = 0;
        const number = () => { const start = i; while (/[0-9.]/.test(expr[i] ?? '')) i++; if (start === i) throw Error('number'); const n = Number(expr.slice(start, i)); if (!Number.isFinite(n)) throw Error('number'); return n; };
        const factor = () => { if (expr[i] === '+') { i++; return factor(); } if (expr[i] === '-') { i++; return -factor(); } if (expr[i] === '(') { i++; const v = add(); if (expr[i++] !== ')') throw Error('paren'); return v; } return number(); };
        const mul = () => { let v = factor(); while (['*','/','%'].includes(expr[i])) { const op = expr[i++], r = factor(); if ((op === '/' || op === '%') && r === 0) throw Error('zero'); v = op === '*' ? v*r : op === '/' ? v/r : v%r; } return v; };
        const add = () => { let v = mul(); while (['+','-'].includes(expr[i])) { const op = expr[i++], r = mul(); v = op === '+' ? v+r : v-r; } return v; };
        const result = add(); if (i !== expr.length || !Number.isFinite(result)) throw Error('invalid');
        await sock.sendMessage(jid, { text: `🧮 ${expr} = ${result}` });
      } catch { await sock.sendMessage(jid, { text: 'Could not calculate that expression. Check the brackets and operators.' }); }
    } },
  { name: 'help', category: 'General', description: 'Show help for a command', run: async ({ sock, jid, args, commands, prefix }) => {
      const name = (args[0] || '').toLowerCase(); const cmd = commands.find(c => c.name === name || c.aliases?.includes(name));
      await sock.sendMessage(jid, { text: cmd ? `*${prefix}${cmd.name}*\nCategory: ${cmd.category}\n${cmd.description}` : `Available commands: ${commands.length}\nUse ${prefix}menu to see the menu.` });
    } }
];
