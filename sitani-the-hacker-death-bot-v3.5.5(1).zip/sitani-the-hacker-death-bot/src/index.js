import 'dotenv/config';
import fs from 'node:fs/promises';
import pino from 'pino';
import makeWASocket, { useMultiFileAuthState, DisconnectReason, Browsers } from '@whiskeysockets/baileys';
import qrcode from 'qrcode-terminal';
import coreCommands from './commands/core.js';
import apiCommands from './commands/apis.js';
import groupCommands, { readJson } from './commands/groups.js';

const env = process.env;
const prefix = env.PREFIX || '.';
const botName = env.BOT_NAME || 'SITANI THE HACKER DEATH';
const ownerNumber = (env.OWNER_NUMBER || '').replace(/\D/g, '');
const commands = [...coreCommands, ...apiCommands, ...groupCommands];
const commandMap = new Map();
for (const command of commands) for (const name of [command.name, ...(command.aliases || [])]) commandMap.set(name, command);
let menuImage = null;
try { menuImage = await fs.readFile(new URL('../assets/menu.jpg', import.meta.url)); } catch { /* menu works without artwork */ }

async function start() {
  const { state, saveCreds } = await useMultiFileAuthState('./auth_info');
  const pairingMode = Boolean(env.PAIRING_NUMBER?.trim());
  const sock = makeWASocket({
    auth: state,
    logger: pino({ level: 'silent' }),
    browser: Browsers.ubuntu('SITANI BOT'),
    printQRInTerminal: false,
    markOnlineOnConnect: false,
    syncFullHistory: false
  });
  sock.ev.on('creds.update', saveCreds);
  sock.ev.on('connection.update', async ({ connection, lastDisconnect, qr }) => {
    if (qr && !pairingMode) {
      console.log('\nScan this QR in WhatsApp > Linked devices > Link a device:');
      qrcode.generate(qr, { small: true });
    }
    if (connection === 'open') console.log(`✅ ${botName} v3.5.5 connected.`);
    if (connection === 'close') {
      const code = lastDisconnect?.error?.output?.statusCode;
      if (code !== DisconnectReason.loggedOut) { console.log('Connection closed; reconnecting...'); setTimeout(start, 3000); }
      else console.log('Logged out. Remove auth_info only if you intend to link again.');
    }
  });
  if (pairingMode && !state.creds.registered) {
    const number = env.PAIRING_NUMBER.replace(/\D/g, '');
    if (number.length < 8) throw new Error('PAIRING_NUMBER must include country code and digits only.');
    const code = await sock.requestPairingCode(number);
    console.log(`\nWhatsApp pairing code: ${code}\nEnter it in WhatsApp > Linked devices > Link with phone number instead.`);
  }

  sock.ev.on('messages.upsert', async ({ messages, type }) => {
    if (type !== 'notify') return;
    for (const message of messages) {
      try {
        if (!message.message || message.key.fromMe) continue;
        const jid = message.key.remoteJid;
        if (!jid || jid === 'status@broadcast') continue;
        const sender = message.key.participant || jid;
        const isGroup = jid.endsWith('@g.us');
        const raw = message.message.conversation || message.message.extendedTextMessage?.text || message.message.imageMessage?.caption || message.message.videoMessage?.caption || '';
        if (!raw.startsWith(prefix)) {
          if (isGroup && (env.ANTI_LINK_DEFAULT === 'true' || (await readJson('settings.json', {}))[jid]?.antilink)) {
            const hasInvite = /chat\.whatsapp\.com\/[A-Za-z0-9]+/i.test(raw);
            if (hasInvite) {
              const metadata = await sock.groupMetadata(jid);
              const botId = sock.user.id.split(':')[0] + '@s.whatsapp.net';
              const botAdmin = metadata.participants.some(p => p.id === botId && ['admin', 'superadmin'].includes(p.admin));
              if (botAdmin) await sock.sendMessage(jid, { delete: message.key });
            }
          }
          continue;
        }
        const [name, ...args] = raw.slice(prefix.length).trim().split(/\s+/);
        const command = commandMap.get((name || '').toLowerCase()); if (!command) continue;
        let metadata = null, senderAdmin = false, botAdmin = false;
        if (isGroup) {
          metadata = await sock.groupMetadata(jid);
          const botId = sock.user.id.split(':')[0] + '@s.whatsapp.net';
          const participant = metadata.participants.find(p => p.id === sender);
          const botParticipant = metadata.participants.find(p => p.id === botId);
          senderAdmin = ['admin', 'superadmin'].includes(participant?.admin);
          botAdmin = ['admin', 'superadmin'].includes(botParticipant?.admin);
        }
        if (command.group && !isGroup) { await sock.sendMessage(jid, { text: 'This command only works in groups.' }); continue; }
        if (command.admin && !senderAdmin && !message.key.fromMe) { await sock.sendMessage(jid, { text: 'Only group admins can use this command.' }); continue; }
        if (command.botAdmin && !botAdmin) { await sock.sendMessage(jid, { text: 'Please make the bot a group admin first.' }); continue; }
        if (command.owner && ownerNumber && sender.replace(/\D/g, '') !== ownerNumber) { await sock.sendMessage(jid, { text: 'Owner-only command.' }); continue; }
        await command.run({ sock, jid, sender, message, args, prefix, botName, ownerNumber, commands, metadata, senderAdmin, botAdmin, isGroup, menuImage, env });
      } catch (error) {
        console.error('Command error:', error?.message || error);
        const jid = message.key.remoteJid;
        if (jid) await sock.sendMessage(jid, { text: 'That command ran into an error. Check the VPS console logs.' }).catch(() => {});
      }
    }
  });
}

start().catch(error => { console.error('Startup failed:', error); process.exit(1); });
